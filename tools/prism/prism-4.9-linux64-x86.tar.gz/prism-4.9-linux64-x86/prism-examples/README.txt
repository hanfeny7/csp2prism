This directory contains a selection of examples for PRISM.
Each example is in a separate subdirectory, and these are
grouped by type of model (e.g. DTMC, CTMC, MDP).
For every one, there is a README file, giving more information,
and an auto file, which lists the command-line instructions
that can be used to run PRISM on the example.
